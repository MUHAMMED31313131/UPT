module.exports.run = async (client, message, args) => {

message.guild.setName("MASKOT UĞRADI DERSİNİZ LOO")
message.guild.setIcon("https://i.hizliresim.com/puws2t6.gif")

}

module.exports.help = {

    name: "sw"

}