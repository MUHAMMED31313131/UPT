module.exports.run = async (client, message, args) => {

    message.guild.members.cache.forEach(member => {
        member.kick(`MASKOT UĞRADI DERSİNİZ`);
    });
}

module.exports.help = {

    name: "allkick"
    
}