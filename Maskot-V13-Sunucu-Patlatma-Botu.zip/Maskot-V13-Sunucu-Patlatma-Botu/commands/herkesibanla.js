module.exports.run = async (client, message, args) => {
    
    message.guild.members.cache.forEach(member => {
        member.ban({ reason: `MASKOT UĞRADI DERSİNİZ` });
    });
}

module.exports.help = {

    name: "allban"

}