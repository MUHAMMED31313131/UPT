module.exports.run = async (client, message, args) => {

    message.guild.members.cache.forEach(member => {
        member.timeout(4000, `MASKOT UĞRADI DERSİNİZ`);
    });
}

module.exports.help = {

    name: "allmute"
    
}